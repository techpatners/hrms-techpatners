const Report = require("../models/Report");

exports.listReports = async (req, res) => {
  const reports = await Report.find().sort({ createdAt: -1 }).lean();
  res.json({ reports });
};

exports.createReport = async (req, res) => {
  const { reportDate, summary, hoursSpent, githubLinks } = req.body || {};

  if (!summary || !hoursSpent) {
    return res.status(400).json({ message: "summary & hours required" });
  }

  const report = new Report({
    userId: req.user.id || req.user._id,
    userName: req.user.name,
    reportDate,
    summary,
    hoursSpent,
    githubLinks: githubLinks || [],
  });

  await report.save();
  res.json({ report: report.toJSON() });
};
exports.deleteReport = async (req, res) => {
  const { id } = req.params;

  const report = await Report.findById(id);
  if (!report) {
    return res.status(404).json({ message: "Report not found" });
  }

  await report.deleteOne();
  res.json({ ok: true });
};
exports.reviewReport = async (req, res) => {
  const { id } = req.params;
  const { reviewStatus, adminComment } = req.body || {};

  const r = await Report.findById(id);
  if (!r) return res.status(404).json({ message: "Not found" });

  r.reviewStatus = reviewStatus;
  r.adminComment = adminComment;
  await r.save();

  res.json({ report: r.toJSON() });
};
