const express = require("express");
const router = express.Router();
const reportsCtrl = require("../controllers/reportsController");
const { auth, adminOnly } = require("../middlewares/authMiddleware");

router.use(auth);

router.get("/", reportsCtrl.listReports);
router.post("/", reportsCtrl.createReport);
router.delete("/:id", auth, adminOnly, reportsCtrl.deleteReport);
// admin review
router.patch("/:id/review", auth, adminOnly, reportsCtrl.reviewReport);

module.exports = router;
