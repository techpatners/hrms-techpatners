import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { Role, MeetingStatus } from "../data/constants";
import {
  Calendar,
  Clock,
  Video,
  Plus,
  Users as UsersIcon,
  ExternalLink,
  X,
} from "lucide-react";

export default function Meetings() {
  const { user } = useAuth();
  const isAdmin = user?.role === Role.ADMIN;

  // ✅ Load from backend
  const [meetings, setMeetings] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const [newMeeting, setNewMeeting] = useState({
    title: "",
    description: "",
    dateTime: "",
    duration: 30,
    link: "",
  });

  const fetchMeetings = async () => {
    try {
      const res = await api("/meetings");
      setMeetings(res.meetings || []);
    } catch (err) {
      console.error("Failed to load meetings:", err);
      setMeetings([]);
    }
  };

  // ✅ 1) Load meetings
  useEffect(() => {
    (async () => {
      const res = await api("/meetings");
      setMeetings(res.meetings || []);
    })();
  }, []);

  // ✅ 2) Create meeting (Admin)
  const handleCreateMeeting = async (e) => {
    e.preventDefault();

    try {
      await api("/meetings", {
        method: "POST",
        body: {
          title: newMeeting.title,
          description: newMeeting.description,
          meetingDateTime: newMeeting.dateTime,
          durationMin: newMeeting.duration,
          meetingLink: newMeeting.link,
          // attendees optional - agar na bhejo to backend ALL users add kar dega
        },
      });

      setShowModal(false);
      setNewMeeting({
        title: "",
        description: "",
        dateTime: "",
        duration: 30,
        link: "",
      });

      const res = await api("/meetings");
      setMeetings(res.meetings || []);
    } catch (err) {
      console.error("Failed to create meeting:", err);
    }
  };

  // ✅ For Interns: show only meetings where they are invited.
  // Backend can send: attendees (array) OR attendeesCount only.
  // We safely handle both cases.
  const myMeetings = meetings.filter((m) => {
    if (isAdmin) return true;
    if (Array.isArray(m.attendees)) {
      return m.attendees.map(String).includes(String(user?.id));
    }
    // If backend doesn't send attendees list for privacy, show all (or you can choose none)
    return true;
  });

  const getAttendeesCount = (meeting) => {
    if (typeof meeting.attendeesCount === "number")
      return meeting.attendeesCount; // ✅ backend sends it
    if (Array.isArray(meeting.attendees)) return meeting.attendees.length;
    return 0;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Meeting Schedule
          </h1>
          <p className="text-xs text-gray-400">
            Synchronous sessions and review meetings.
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowModal(true)}
            className="inline-flex items-center px-5 py-2.5 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors shadow-lg text-sm font-bold"
          >
            <Plus size={16} className="mr-2" />
            Schedule Session
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {myMeetings.map((meeting) => (
          <div
            key={meeting.id} // ✅ backend returns id
            className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-all group"
          >
            <div className="bg-slate-50 p-6 flex items-start justify-between border-b border-slate-100">
              <div className="p-3 bg-white rounded-xl shadow-sm text-slate-900 border border-slate-100">
                <Video size={20} />
              </div>

              <span
                className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                  meeting.status === MeetingStatus.SCHEDULED
                    ? "bg-slate-900 text-white border-slate-900"
                    : "bg-white text-slate-400 border-slate-200"
                }`}
              >
                {meeting.status}
              </span>
            </div>

            <div className="p-6 flex-1 space-y-4">
              <div>
                <h3 className="text-md font-bold text-slate-900 group-hover:text-slate-700 transition-colors">
                  {meeting.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {meeting.description}
                </p>
              </div>

              <div className="space-y-2.5">
                <div className="flex items-center text-[11px] text-slate-600 font-bold">
                  <Calendar size={12} className="mr-2.5 text-slate-400" />
                  <span>
                    {new Date(meeting.meetingDateTime).toLocaleDateString(
                      "en-US",
                      { dateStyle: "medium" }
                    )}
                  </span>
                </div>

                <div className="flex items-center text-[11px] text-slate-600 font-bold">
                  <Clock size={12} className="mr-2.5 text-slate-400" />
                  <span>
                    {new Date(meeting.meetingDateTime).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}{" "}
                    ({meeting.durationMin} min)
                  </span>
                </div>

                <div className="flex items-center text-[11px] text-slate-600 font-bold">
                  <UsersIcon size={12} className="mr-2.5 text-slate-400" />
                  <span>{getAttendeesCount(meeting)} Participants</span>
                </div>
              </div>

              {meeting.meetingLink && (
                <a
                  href={meeting.meetingLink}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center w-full py-2.5 bg-slate-900 text-white rounded-xl font-bold text-xs hover:bg-slate-800 transition-all shadow-md active:scale-95"
                >
                  Join via Portal <ExternalLink size={10} className="ml-1.5" />
                </a>
              )}
            </div>
          </div>
        ))}

        {myMeetings.length === 0 && (
          <div className="bg-white rounded-xl border border-slate-100 p-8 text-slate-400 text-sm">
            No meetings found.
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
              <h2 className="text-lg font-bold text-sm uppercase tracking-widest">
                Schedule Meeting
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="hover:rotate-90 transition-transform"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleCreateMeeting} className="p-8 space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                  Session Title
                </label>
                <input
                  type="text"
                  required
                  value={newMeeting.title}
                  onChange={(e) =>
                    setNewMeeting({ ...newMeeting, title: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  placeholder="e.g. Design Review Session"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                  Brief Agenda
                </label>
                <textarea
                  required
                  rows={2}
                  value={newMeeting.description}
                  onChange={(e) =>
                    setNewMeeting({
                      ...newMeeting,
                      description: e.target.value,
                    })
                  }
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  placeholder="Items to be discussed..."
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                    Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={newMeeting.dateTime}
                    onChange={(e) =>
                      setNewMeeting({ ...newMeeting, dateTime: e.target.value })
                    }
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                    Duration (Min)
                  </label>
                  <input
                    type="number"
                    required
                    step="15"
                    value={newMeeting.duration}
                    onChange={(e) =>
                      setNewMeeting({
                        ...newMeeting,
                        duration: parseInt(e.target.value || "0", 10),
                      })
                    }
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                  Streaming URL
                </label>
                <input
                  type="url"
                  value={newMeeting.link}
                  onChange={(e) =>
                    setNewMeeting({ ...newMeeting, link: e.target.value })
                  }
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  placeholder="https://meet.google.com/..."
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-3 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-bold text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-slate-900 text-white rounded-xl hover:bg-slate-800 font-bold text-sm shadow-lg transition-all"
                >
                  Schedule Now
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
