import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { Role, ReportStatus } from "../data/constants";
import {
  Send,
  Clock,
  Github,
  Check,
  XCircle,
  MessageSquare,
  Calendar,
  X,
} from "lucide-react";

export default function Reports() {
  const { user } = useAuth();
  const isAdmin = user?.role === Role.ADMIN;

  // ✅ Load from backend
  const [reports, setReports] = useState([]);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [reviewComment, setReviewComment] = useState("");

  const [newReport, setNewReport] = useState({
    summary: "",
    hoursSpent: 8,
    githubLink: "",
  });

  const fetchReports = async () => {
    try {
      const res = await api("/reports");
      setReports(res.reports || []);
    } catch (err) {
      console.error("Failed to load reports:", err);
      setReports([]);
    }
  };

  // ✅ 1) Load reports
  useEffect(() => {
    (async () => {
      const res = await api("/reports");
      setReports(res.reports || []);
    })();
  }, []);

  // ✅ 2) Submit report (Intern)
  const handleSubmitReport = async (e) => {
    e.preventDefault();

    try {
      await api("/reports", {
        method: "POST",
        body: {
          reportDate: new Date().toISOString().split("T")[0],
          summary: newReport.summary,
          hoursSpent: newReport.hoursSpent,
          githubLinks: newReport.githubLink ? [newReport.githubLink] : [],
        },
      });

      setShowSubmitModal(false);
      setNewReport({ summary: "", hoursSpent: 8, githubLink: "" });

      const res = await api("/reports");
      setReports(res.reports || []);
    } catch (err) {
      console.error("Failed to submit report:", err);
    }
  };

  // ✅ 3) Admin review report
  const handleReview = async (reportId, status) => {
    try {
      await api(`/reports/${reportId}/review`, {
        method: "PATCH",
        body: {
          reviewStatus: status,
          adminComment: reviewComment,
        },
      });

      setSelectedReport(null);
      setReviewComment("");

      const res = await api("/reports");
      setReports(res.reports || []);
    } catch (err) {
      console.error("Failed to review report:", err);
    }
  };

  const filteredReports = isAdmin
    ? reports
    : reports.filter((r) => String(r.userId) === String(user?.id));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Work Journals
          </h1>
          <p className="text-xs text-gray-400">
            Daily progress reports and effort tracking.
          </p>
        </div>

        {!isAdmin && (
          <button
            onClick={() => setShowSubmitModal(true)}
            className="inline-flex items-center px-5 py-2.5 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors shadow-lg text-sm font-bold"
          >
            <Send size={16} className="mr-2" />
            Submit Journal
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-100">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Date
                </th>
                {isAdmin && (
                  <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Intern
                  </th>
                )}
                <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Summary
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Effort
                </th>
                <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Status
                </th>
                <th className="px-6 py-4 text-right text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody className="bg-white divide-y divide-slate-50">
              {filteredReports.map((report) => (
                <tr
                  key={report.id} // ✅ backend returns id
                  className="hover:bg-slate-50/50 transition-colors group"
                >
                  <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-900 font-bold">
                    {report.reportDate}
                  </td>

                  {isAdmin && (
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-md bg-slate-900 flex items-center justify-center text-white font-extrabold text-[9px] mr-2">
                          {(report.userName || "IN")
                            .substring(0, 2)
                            .toUpperCase()}
                        </div>
                        <span className="text-xs text-slate-700 font-medium">
                          {report.userName}
                        </span>
                      </div>
                    </td>
                  )}

                  <td className="px-6 py-4 text-xs text-slate-400 max-w-xs truncate font-medium">
                    {report.summary}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-500 font-bold">
                    {report.hoursSpent}h
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2.5 py-1 inline-flex text-[9px] font-extrabold rounded-full border uppercase ${
                        report.reviewStatus === ReportStatus.APPROVED
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : report.reviewStatus === ReportStatus.NEEDS_CHANGES
                          ? "bg-rose-50 text-rose-700 border-rose-100"
                          : "bg-slate-50 text-slate-600 border-slate-100"
                      }`}
                    >
                      {report.reviewStatus}
                    </span>
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap text-right text-xs font-bold">
                    <button
                      onClick={() => {
                        setSelectedReport(report);
                        setReviewComment(report.adminComment || "");
                      }}
                      className="text-slate-900 hover:underline"
                    >
                      {isAdmin ? "Review" : "View"}
                    </button>
                  </td>
                </tr>
              ))}

              {filteredReports.length === 0 && (
                <tr>
                  <td
                    colSpan={isAdmin ? 6 : 5}
                    className="px-6 py-10 text-center text-sm text-slate-400"
                  >
                    No reports found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden border border-slate-100">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
              <h2 className="text-lg font-bold uppercase tracking-widest text-sm">
                Work Record
              </h2>
              <button
                onClick={() => setSelectedReport(null)}
                className="hover:rotate-90 transition-transform"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-8 space-y-8 overflow-y-auto max-h-[85vh]">
              <div className="flex justify-between items-start border-b border-slate-100 pb-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-900 font-black text-lg mr-4">
                    {(selectedReport.userName || "I").substring(0, 1)}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                      Intern
                    </p>
                    <p className="text-lg font-bold text-slate-900">
                      {selectedReport.userName}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Journal Date
                  </p>
                  <p className="text-lg font-bold text-slate-900">
                    {selectedReport.reportDate}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest mb-3">
                  Daily Summary
                </h3>
                <div className="bg-slate-50 p-6 rounded-xl border border-slate-100 text-slate-600 text-sm whitespace-pre-wrap leading-relaxed">
                  {selectedReport.summary}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                    Total Effort
                  </h3>
                  <div className="flex items-center text-slate-900 font-extrabold text-md">
                    <Clock size={16} className="mr-2 text-slate-400" />
                    {selectedReport.hoursSpent} Hours
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                    Deliverables
                  </h3>
                  {selectedReport.githubLinks?.length > 0 ? (
                    <div className="space-y-1">
                      {selectedReport.githubLinks.map((link, i) => (
                        <a
                          key={i}
                          href={link}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center text-slate-900 hover:underline text-[11px] font-bold"
                        >
                          <Github size={12} className="mr-2 text-slate-400" />
                          Source Link {i + 1}
                        </a>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic font-medium">
                      No links provided
                    </p>
                  )}
                </div>
              </div>

              {selectedReport.adminComment && (
                <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 text-white shadow-lg">
                  <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center">
                    <MessageSquare size={12} className="mr-2 text-slate-500" />
                    Management Feedback
                  </h3>
                  <p className="text-sm font-medium leading-relaxed opacity-90">
                    {selectedReport.adminComment}
                  </p>
                </div>
              )}

              {isAdmin &&
                selectedReport.reviewStatus === ReportStatus.PENDING && (
                  <div className="border-t border-slate-100 pt-8 space-y-4">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest">
                      Admin Review
                    </h3>

                    <textarea
                      placeholder="Provide constructive feedback..."
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm min-h-[100px]"
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                    />

                    <div className="flex gap-4">
                      <button
                        onClick={() =>
                          handleReview(
                            selectedReport.id,
                            ReportStatus.NEEDS_CHANGES
                          )
                        }
                        className="flex-1 py-3 px-4 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-colors font-bold flex items-center justify-center text-sm shadow-sm"
                      >
                        <XCircle size={16} className="mr-2 text-rose-500" />
                        Revise
                      </button>

                      <button
                        onClick={() =>
                          handleReview(selectedReport.id, ReportStatus.APPROVED)
                        }
                        className="flex-1 py-3 px-4 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors font-bold flex items-center justify-center text-sm shadow-lg"
                      >
                        <Check size={16} className="mr-2 text-emerald-400" />
                        Approve
                      </button>
                    </div>
                  </div>
                )}
            </div>
          </div>
        </div>
      )}

      {/* Submit Journal Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-100">
            <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
              <h2 className="text-lg font-bold text-sm uppercase tracking-widest">
                New Journal Entry
              </h2>
              <button
                onClick={() => setShowSubmitModal(false)}
                className="hover:rotate-90 transition-transform"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="p-8 space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                  What did you achieve today?
                </label>
                <textarea
                  required
                  rows={4}
                  value={newReport.summary}
                  onChange={(e) =>
                    setNewReport({ ...newReport, summary: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm min-h-[120px]"
                  placeholder="Focus on results and outcomes..."
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                    Effort (Hours)
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="24"
                    value={newReport.hoursSpent}
                    onChange={(e) =>
                      setNewReport({
                        ...newReport,
                        hoursSpent: parseInt(e.target.value || "0", 10),
                      })
                    }
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                    Entry Date
                  </label>
                  <div className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-400 text-sm font-bold flex items-center">
                    <Calendar size={14} className="mr-2" />
                    {new Date().toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                  Deliverable URL
                </label>
                <input
                  type="url"
                  value={newReport.githubLink}
                  onChange={(e) =>
                    setNewReport({ ...newReport, githubLink: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-slate-900 text-sm"
                  placeholder="https://github.com/techpatners/..."
                />
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="flex-1 py-3 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-bold text-sm"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-slate-900 text-white rounded-xl hover:bg-slate-800 font-bold text-sm shadow-lg transition-all active:scale-95"
                >
                  Submit Journal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
