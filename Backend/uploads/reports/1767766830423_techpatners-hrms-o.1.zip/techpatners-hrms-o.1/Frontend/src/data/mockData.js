import {
  Role,
  TaskStatus,
  ReportStatus,
  MeetingStatus,
} from "../constants/enums";

export const INITIAL_USERS = [
  {
    id: "1",
    name: "Admin User",
    email: "admin@techpatners.com",
    role: Role.ADMIN,
    joinDate: "2023-01-01",
    avatar: "https://picsum.photos/seed/admin/200",
  },
  {
    id: "2",
    name: "John Intern",
    email: "john@techpatners.com",
    role: Role.INTERN,
    joinDate: "2024-05-15",
    batch: "Batch 2024-A",
    team: "Frontend Dev",
    avatar: "https://picsum.photos/seed/john/200",
  },
  {
    id: "3",
    name: "Sarah Coder",
    email: "sarah@techpatners.com",
    role: Role.INTERN,
    joinDate: "2024-05-15",
    batch: "Batch 2024-A",
    team: "Backend Dev",
    avatar: "https://picsum.photos/seed/sarah/200",
  },
];

export const INITIAL_TASKS = [
  {
    id: "t1",
    title: "Setup Project Boilerplate",
    description:
      "Initialize React + Vite project with Tailwind CSS and basic routing.",
    assignedTo: "2",
    assignedToName: "John Intern",
    assignedBy: "1",
    dueDate: "2024-06-10",
    priority: "High",
    status: TaskStatus.DONE,
    githubLink: "https://github.com/techpatners/hrms-v1",
    comments: ["Please use TypeScript."],
    createdAt: "2024-06-01",
  },
  {
    id: "t2",
    title: "API Authentication Layer",
    description: "Implement JWT based authentication with bcrypt hashing.",
    assignedTo: "3",
    assignedToName: "Sarah Coder",
    assignedBy: "1",
    dueDate: "2024-06-15",
    priority: "Medium",
    status: TaskStatus.IN_PROGRESS,
    comments: [],
    createdAt: "2024-06-05",
  },
  {
    id: "t3",
    title: "Dashboard Design",
    description: "Create a professional slate and white dashboard for interns.",
    assignedTo: "2",
    assignedToName: "John Intern",
    assignedBy: "1",
    dueDate: "2024-06-20",
    priority: "Medium",
    status: TaskStatus.PENDING,
    comments: [],
    createdAt: "2024-06-08",
  },
];

export const INITIAL_REPORTS = [
  {
    id: "r1",
    userId: "2",
    userName: "John Intern",
    reportDate: "2024-06-05",
    summary:
      "Finished setting up the Tailwind configuration and started building the Navbar component.",
    hoursSpent: 6,
    githubLinks: ["https://github.com/techpatners/hrms-v1/commit/abc123"],
    attachments: [],
    reviewStatus: ReportStatus.APPROVED,
    adminComment: "Good progress, John!",
    createdAt: "2024-06-05T18:00:00Z",
    updatedAt: "2024-06-05T19:00:00Z",
  },
  {
    id: "r2",
    userId: "3",
    userName: "Sarah Coder",
    reportDate: "2024-06-06",
    summary:
      "Configuring Mongoose models and testing the connection to MongoDB Atlas.",
    hoursSpent: 5,
    githubLinks: [],
    attachments: [],
    reviewStatus: ReportStatus.PENDING,
    createdAt: "2024-06-06T17:30:00Z",
    updatedAt: "2024-06-06T17:30:00Z",
  },
];

export const INITIAL_MEETINGS = [
  {
    id: "m1",
    title: "Weekly Sync-up",
    description: "General progress update for all interns.",
    meetingDateTime: "2024-06-12T10:00:00",
    durationMin: 45,
    attendees: ["1", "2", "3"],
    createdBy: "1",
    meetingLink: "https://meet.google.com/abc-defg-hij",
    status: MeetingStatus.SCHEDULED,
  },
];

export const INITIAL_ANNOUNCEMENTS = [
  {
    id: "a1",
    title: "Orientation Tomorrow",
    message:
      "Welcome all interns! Please join the orientation meeting at 10 AM.",
    createdBy: "1",
    createdAt: "2024-06-01T09:00:00Z",
  },
];
