const Announcement = require("../models/Announcement");

exports.list = async (req, res) => {
  const announcements = await Announcement.find().sort({ createdAt: -1 }).lean();
  res.json({ announcements });
};

exports.create = async (req, res) => {
  const { title, message } = req.body || {};
  const a = new Announcement({ title, message, createdBy: req.user.id });
  await a.save();
  res.json({ announcement: a });
};

exports.remove = async (req, res) => {
  await Announcement.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
};
