const Task = require("../models/Task");
const User = require("../models/User");

exports.listTasks = async (req, res) => {
  const tasks = await Task.find().sort({ createdAt: -1 }).lean();
  res.json({ tasks });
};

exports.createTask = async (req, res) => {
  const { title, description, assignedTo, dueDate, priority } = req.body || {};
  const assignedToUser = assignedTo ? await User.findById(assignedTo) : null;
  const task = new Task({
    title, description, assignedTo, assignedToName: assignedToUser?.name, assignedBy: req.user.id, dueDate, priority
  });
  await task.save();
  res.json({ task });
};

exports.updateStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body || {};
  const task = await Task.findById(id);
  if (!task) return res.status(404).json({ message: "Not found" });
  task.status = status;
  await task.save();
  res.json({ task });
};
