const Report = require("../models/Report");

exports.listReports = async (req, res) => {
  const reports = await Report.find().sort({ createdAt: -1 }).lean();
  res.json({ reports });
};

exports.createReport = async (req, res) => {
  const { reportDate, summary, hoursSpent, githubLinks } = req.body || {};
  const r = new Report({
    userId: req.user.id,
    userName: req.user.name,
    reportDate,
    summary,
    hoursSpent,
    githubLinks: githubLinks || []
  });
  await r.save();
  res.json({ report: r });
};

exports.reviewReport = async (req, res) => {
  const { id } = req.params;
  const { reviewStatus, adminComment } = req.body || {};
  const r = await Report.findById(id);
  if (!r) return res.status(404).json({ message: "Not found" });
  r.reviewStatus = reviewStatus;
  r.adminComment = adminComment;
  await r.save();
  res.json({ report: r });
};
