const express = require("express");
const router = express.Router();
const tasksCtrl = require("../controllers/tasksController");
const { auth } = require("../middlewares/authMiddleware");

router.use(auth);

router.get("/", tasksCtrl.listTasks);
router.post("/", tasksCtrl.createTask);
router.patch("/:id/status", tasksCtrl.updateStatus);

module.exports = router;
