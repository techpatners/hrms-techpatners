const express = require("express");
const router = express.Router();
const announcementsCtrl = require("../controllers/announcementsController");
const { auth, adminOnly } = require("../middlewares/authMiddleware");

router.get("/", announcementsCtrl.list);
router.post("/", auth, adminOnly, announcementsCtrl.create);
router.delete("/:id", auth, adminOnly, announcementsCtrl.remove);

module.exports = router;
