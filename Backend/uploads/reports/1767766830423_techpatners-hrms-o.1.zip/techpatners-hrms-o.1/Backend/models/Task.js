const mongoose = require("mongoose");

const TaskSchema = new mongoose.Schema({
  title: String,
  description: String,
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  assignedToName: String,
  assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  dueDate: String,
  priority: { type: String, enum: ["Low","Medium","High"], default: "Medium" },
  status: { type: String, default: "Pending" }
}, { timestamps: true });

TaskSchema.set("toJSON", {
  transform(doc, ret) { ret.id = ret._id.toString(); delete ret._id; delete ret.__v; }
});

module.exports = mongoose.model("Task", TaskSchema);
